-- AlterEnum
ALTER TYPE "ProjectType" ADD VALUE 'REACT';
